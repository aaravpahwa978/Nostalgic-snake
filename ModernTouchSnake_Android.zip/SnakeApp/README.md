# Modern Touch Snake (Android)
WebView app. minSdk 21 (Android 5.0), target/compile SDK 36. Game is fully offline (Tailwind CSS + Inter font bundled in app/src/main/assets).

Build: open this folder in Android Studio and press Run, or `gradle assembleDebug`
(APK: app/build/outputs/apk/debug/app-debug.apk). Or push to GitHub: the included Actions workflow builds the APK.
